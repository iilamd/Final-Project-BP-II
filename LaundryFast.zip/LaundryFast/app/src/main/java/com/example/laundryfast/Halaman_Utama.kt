package com.example.laundryfast

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.laundryfast.laundry_fast.Laundry_Fast
import com.example.laundryfast.laundry_kilat.Laundry_kilat
import com.example.laundryfast.laundry_kilat.Tambah_Kilat
import com.example.laundryfast.laundry_reguler.Laundry_reguler

class Halaman_Utama : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.halaman_utama)

        val btn_laundry1: LinearLayout = findViewById(R.id.btn_laundry1)
        val btn_laundry2: LinearLayout = findViewById(R.id.btn_laundry2)
        val btn_laundry3: LinearLayout = findViewById(R.id.btn_laundry3)
        val btn_keluar: ImageView = findViewById(R.id.btn_keluar)


        btn_laundry1.setOnClickListener {
            val pindah = Intent(this, Laundry_kilat::class.java)
            startActivity(pindah)
        }
        btn_laundry2.setOnClickListener {
            val pindah = Intent(this, Laundry_Fast::class.java)
            startActivity(pindah)
        }
        btn_laundry3.setOnClickListener {
            val pindah = Intent(this, Laundry_reguler::class.java)
            startActivity(pindah)
        }
        btn_keluar.setOnClickListener {
            val pindah = Intent(this, Login::class.java)
            startActivity(pindah)
        }
    }
}