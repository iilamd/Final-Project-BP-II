package com.example.laundryfast.laundry_kilat

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.laundryfast.Halaman_Utama
import com.example.laundryfast.Login
import com.example.laundryfast.R

class Laundry_kilat : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.laundry_kilat)

        val rv_kilat: RecyclerView = findViewById(R.id.rv_kilat)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val berat: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()

        val dbpetshop: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
        val tampilproduk = dbpetshop.rawQuery("SELECT * FROM Kilat", null)

        while (tampilproduk.moveToNext()) {
            id.add(tampilproduk.getString(0))
            nama.add(tampilproduk.getString(1))
            berat.add(tampilproduk.getString(2))
            harga.add(tampilproduk.getString(3))
        }

        val item: Item_Laundry_Kilat = Item_Laundry_Kilat(this, id, nama,berat, harga)
        rv_kilat.adapter = item
        rv_kilat.layoutManager = LinearLayoutManager(this)

        val btn_logout: ImageView = findViewById(R.id.btn_keluar)
        btn_logout.setOnClickListener {
            val pindah = Intent(this, Login::class.java)
            startActivity(pindah)
        }


        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Halaman_Utama::class.java)
            startActivity(pindah)
        }

        val btn_tambah: TextView = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah = Intent(this, Tambah_Kilat::class.java)
            startActivity(pindah)
        }
    }
}