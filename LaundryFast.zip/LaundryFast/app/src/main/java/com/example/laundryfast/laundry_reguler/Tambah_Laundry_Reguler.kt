package com.example.laundryfast.laundry_reguler

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import com.example.laundryfast.R
import com.example.laundryfast.laundry_kilat.Laundry_kilat

class Tambah_Laundry_Reguler : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.tambah_laundry_reguler)

        val txt_pelanggan: EditText = findViewById(R.id.txt_pelanggan)
        val txt_berat: EditText = findViewById(R.id.txt_berat)
        val txt_harga: EditText = findViewById(R.id.txt_harga)
        val btn_simpan: LinearLayout = findViewById(R.id.btn_tambah)

        btn_simpan.setOnClickListener {
            val isi_pelanggan:String = txt_pelanggan.text.toString()
            val isi_berat:String = txt_berat.text.toString()
            val isi_harga:String = txt_harga.text.toString()

            val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
            val eksekutor = dblaundry.rawQuery("INSERT INTO Reguler(pelanggan_laundry_reguler, berat_laundry_reguler, harga_laundry_reguler) VALUES('$isi_pelanggan','$isi_berat','$isi_harga')",null)
            eksekutor.moveToNext()

            val pindah: Intent = Intent(this, Laundry_reguler::class.java)
            startActivity(pindah)
        }

        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Laundry_reguler::class.java)
            startActivity(pindah)
        }
    }
}