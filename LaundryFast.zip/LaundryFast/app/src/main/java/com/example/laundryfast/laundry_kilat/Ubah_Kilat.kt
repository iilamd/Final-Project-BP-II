package com.example.laundryfast.laundry_kilat

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import com.example.laundryfast.R

class Ubah_Kilat : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ubah_kilat)

        val id_terpilih:String = intent.getStringExtra("id_terpilih").toString()

        val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
        val ambil = dblaundry.rawQuery("select * from Kilat where id_laundry_kilat ='$id_terpilih'", null)
        ambil.moveToNext()

        val isi_nama:String = ambil.getString(1)
        val isi_berat:String = ambil.getString(2)
        val isi_harga:String = ambil.getString(3)

        val txt_nama: EditText = findViewById(R.id.txt_pelanggan)
        val txt_berat: EditText = findViewById(R.id.txt_berat)
        val txt_harga: EditText = findViewById(R.id.txt_harga)
        val btn_simpan: LinearLayout = findViewById(R.id.btn_ubah)

        txt_nama.setText(isi_nama)
        txt_berat.setText(isi_berat)
        txt_harga.setText(isi_harga)

        btn_simpan.setOnClickListener {
            val nama_baru:String = txt_nama.text.toString()
            val berat_baru:String = txt_berat.text.toString()
            val harga_baru:String = txt_harga.text.toString()

            val ngubah = dblaundry.rawQuery("UPDATE Kilat SET pelanggan_laundry_kilat = '$nama_baru', berat_laundry_kilat = '$berat_baru', harga_laundry_kilat = '$harga_baru' where id_laundry_kilat = '$id_terpilih'", null)
            ngubah.moveToNext()

            val pindah: Intent = Intent(this, Laundry_kilat::class.java)
            startActivity(pindah)
        }

        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Laundry_kilat::class.java)
            startActivity(pindah)
        }
    }
}