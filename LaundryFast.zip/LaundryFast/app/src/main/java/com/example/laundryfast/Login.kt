package com.example.laundryfast

import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        val txt_email: EditText = findViewById(R.id.txt_email)
        val txt_password: EditText = findViewById(R.id.txt_password)
        val btn_login: LinearLayout = findViewById(R.id.btn_login)

        btn_login.setOnClickListener {
            val isi_email:String = txt_email.text.toString()
            val isi_password:String = txt_password.text.toString()

            val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)

            val query = dblaundry.rawQuery("SELECT * FROM admin WHERE email_admin='$isi_email' AND password_admin='$isi_password'", null)
            val cek = query.moveToNext()

            if (cek)
            {
                val id = query.getString(0)
                val email = query.getString(1)
                val password = query.getString(2)

                val session: SharedPreferences = getSharedPreferences("admin", MODE_PRIVATE)
                val masuk = session.edit()
                masuk.putString("id_admin", id)
                masuk.putString("email_admin", email)
                masuk.putString("password_admin", password)
                masuk.commit()


                val pindah: Intent = Intent(this, Halaman_Utama::class.java)
                startActivity(pindah)
                finish()
            } else {
                Toast.makeText(this, "Email atau Password anda Salah DULLL!!!!", Toast.LENGTH_LONG).show()
            }
        }
    }
}