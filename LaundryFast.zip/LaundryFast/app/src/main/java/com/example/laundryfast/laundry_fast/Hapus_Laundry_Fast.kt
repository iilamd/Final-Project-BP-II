package com.example.laundryfast.laundry_fast

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.laundryfast.R
import com.example.laundryfast.laundry_reguler.Laundry_reguler

class Hapus_Laundry_Fast : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hapus_laundry_fast)

        val id_terpilih:String = intent.getStringExtra("id_terpilih").toString()

        val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
        val query = dblaundry.rawQuery("delete from Fast where id_laundry_fast='$id_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Laundry_Fast::class.java)
        startActivity(pindah)
    }
}