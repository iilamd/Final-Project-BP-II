package com.example.laundryfast.laundry_reguler

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.laundryfast.R
import com.example.laundryfast.laundry_kilat.Laundry_kilat

class Hapus_Laundry_Reguler : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.hapus_laundry_reguler)

        val id_terpilih:String = intent.getStringExtra("id_terpilih").toString()

        val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
        val query = dblaundry.rawQuery("delete from Reguler where id_laundry_reguler='$id_terpilih'", null)
        query.moveToNext()

        val pindah: Intent = Intent(this, Laundry_reguler::class.java)
        startActivity(pindah)
    }
}