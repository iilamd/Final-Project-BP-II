package com.example.laundryfast.laundry_fast

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.laundryfast.R
import com.example.laundryfast.laundry_reguler.Hapus_Laundry_Reguler
import com.example.laundryfast.laundry_reguler.Ubah_Laundry_Reguler

class Item_Laundry_Fast(
    val ini: Context,
    val id: MutableList<String>,
    val nama: MutableList<String>,
    val berat: MutableList<String>,
    val harga: MutableList<String>
) : RecyclerView.Adapter<Item_Laundry_Fast.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_laundry_fast, parent, false)
        return ViewHolder(view)
    }

    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        // Gunakan safe call operator (?) untuk menghindari NullPointerException
        val txt_nama: TextView? = itemView.findViewById(R.id.txt_nama)
        val txt_berat: TextView? = itemView.findViewById(R.id.txt_berat)
        val txt_harga: TextView? = itemView.findViewById(R.id.txt_harga)
        val btn_edit: TextView? = itemView.findViewById(R.id.btn_edit)
        val btn_hapus: TextView? = itemView.findViewById(R.id.btn_hapus)
    }

    override fun getItemCount(): Int {
        return nama.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        // Periksa apakah txt_nama, txt_berat, dan txt_harga tidak null sebelum mengakses properti
        holder.txt_nama?.text = nama.getOrNull(position) ?: "Default Name"
        holder.txt_berat?.text = berat.getOrNull(position) ?: "Default Weight"
        holder.txt_harga?.text = harga.getOrNull(position) ?: "Default Price"

        holder.btn_edit?.setOnClickListener {
            val id_terpilih: String? = id.getOrNull(position)
            id_terpilih?.let {
                val pindah: Intent = Intent(ini, Ubah_Laundry_Fast::class.java)
                pindah.putExtra("id_terpilih", it)
                ini.startActivity(pindah)
            }
        }

        holder.btn_hapus?.setOnClickListener {
            val id_terpilih: String? = id.getOrNull(position)
            id_terpilih?.let {
                val pindah: Intent = Intent(ini, Hapus_Laundry_Fast::class.java)
                pindah.putExtra("id_terpilih", it)
                ini.startActivity(pindah)
            }
        }
    }
}