package com.example.laundryfast.laundry_fast

import android.annotation.SuppressLint
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.laundryfast.Halaman_Utama
import com.example.laundryfast.Login
import com.example.laundryfast.R
import com.example.laundryfast.laundry_reguler.Item_Laundry_Reguler
import com.example.laundryfast.laundry_reguler.Tambah_Laundry_Reguler

class Laundry_Fast : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.laundry_fast)

        val rv_fast: RecyclerView = findViewById(R.id.rv_fast)

        val id: MutableList<String> = mutableListOf()
        val nama: MutableList<String> = mutableListOf()
        val berat: MutableList<String> = mutableListOf()
        val harga: MutableList<String> = mutableListOf()

        val dblaundry: SQLiteDatabase = openOrCreateDatabase("Laundry", MODE_PRIVATE, null)
        val tampilproduk = dblaundry.rawQuery("SELECT * FROM Fast", null)

        while (tampilproduk.moveToNext()) {
            id.add(tampilproduk.getString(0))
            nama.add(tampilproduk.getString(1))
            berat.add(tampilproduk.getString(2))
            harga.add(tampilproduk.getString(3))
        }

        val item: Item_Laundry_Fast = Item_Laundry_Fast(this, id, nama,berat, harga)
        rv_fast.adapter = item
        rv_fast.layoutManager = LinearLayoutManager(this)

        val btn_logout: ImageView = findViewById(R.id.btn_keluar)
        btn_logout.setOnClickListener {
            val pindah = Intent(this, Login::class.java)
            startActivity(pindah)
        }


        val btn_kembali: ImageView = findViewById(R.id.btn_kembali)
        btn_kembali.setOnClickListener {
            val pindah = Intent(this, Halaman_Utama::class.java)
            startActivity(pindah)
        }

        val btn_tambah: TextView = findViewById(R.id.btn_tambah)
        btn_tambah.setOnClickListener {
            val pindah = Intent(this, Tambah_Laundry_Fast::class.java)
            startActivity(pindah)
        }
    }
}